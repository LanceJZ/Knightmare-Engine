#include "GameLogic.h"

GameLogic::GameLogic()
{

}

GameLogic::~GameLogic()
{
}

void GameLogic::Load()
{

}

bool GameLogic::BeginRun()
{

	return false;
}

void GameLogic::Input()
{

}

void GameLogic::Update(float deltaTime)
{

}

void GameLogic::Draw3D()
{

}

void GameLogic::Draw2D()
{

}
